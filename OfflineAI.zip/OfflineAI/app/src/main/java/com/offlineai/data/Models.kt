package com.offlineai.data

data class AiModel(
    val id: String,
    val name: String,
    val parameters: String,
    val sizeGB: String,
    val bestFor: String,
    val description: String
)

val availableModels = listOf(
    AiModel(
        id = "fast",
        name = "Fast",
        parameters = "1.5B",
        sizeGB = "1.1 GB",
        bestFor = "Everyday chatting",
        description = "Quick responses for daily conversations"
    ),
    AiModel(
        id = "balanced",
        name = "Balanced",
        parameters = "2B",
        sizeGB = "1.4 GB",
        bestFor = "Speed + quality",
        description = "Good balance of speed and intelligence"
    ),
    AiModel(
        id = "smart",
        name = "Smart",
        parameters = "3B",
        sizeGB = "2.0 GB",
        bestFor = "Better reasoning",
        description = "Higher quality answers and reasoning"
    )
)
