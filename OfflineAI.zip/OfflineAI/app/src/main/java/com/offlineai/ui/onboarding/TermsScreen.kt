package com.offlineai.ui.onboarding

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun TermsScreen(onAccepted: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text(
            text = "Terms and Conditions",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Last updated: September 20, 2026",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = """
By using Offline AI, you agree to these Terms and Conditions. Please read them before using the application.

1. About Offline AI

Offline AI is an application that allows users to interact with artificial intelligence models. Some models may run directly on the user's Android device without an internet connection. Optional cloud-based features may send requests through our servers to third-party AI inference services.

2. Your Information

The name you provide during setup is used to personalize the application. The application may store your name and application preferences locally on your device.

Conversation history may also be stored locally so that you can reopen previous conversations.

Cloud AI requests may be transmitted to our backend and the relevant AI service when you choose to use an online model. Do not submit information that you do not want transmitted to a third-party service.

3. AI-Generated Content

AI-generated responses may be inaccurate, incomplete, outdated, or misleading. You are responsible for checking important information before relying on it.

Offline AI is not a replacement for qualified professional advice in areas such as medicine, law, finance, education, safety, or other high-impact decisions.

4. Appropriate Use

You agree to use Offline AI lawfully and responsibly.

You must not use the application to deliberately cause harm, facilitate illegal activity, violate another person's privacy, distribute malicious software, or otherwise misuse the service.

The application may restrict or refuse certain requests for safety reasons.

5. Local Models

Offline models are provided for use according to the licenses applicable to those models and their associated components.

Individual models may have different licenses, capabilities, limitations, and usage requirements. Those requirements remain applicable when using the relevant model.

6. Cloud Models

Cloud models are provided through third-party infrastructure and services. Availability, limits, pricing, model behavior, and performance may change without notice.

Offline AI does not guarantee that a particular cloud model or provider will always be available.

7. Device Performance

Running AI models locally may consume significant CPU, GPU, RAM, storage, battery power, and device resources. Performance depends on the Android device and the selected model.

The application may automatically select, unload, or restrict models to reduce crashes and excessive resource usage.

8. No Guarantee

Offline AI is provided on an "as available" basis. We do not guarantee that the application, models, generated responses, or cloud services will always be available, accurate, secure, or error-free.

9. Updates

The application, bundled models, safety systems, supported devices, and available cloud services may be changed or updated over time.

10. User Responsibility

You are responsible for how you use the application and for decisions made from AI-generated information.

Do not rely on an AI response as the sole basis for decisions involving significant personal, financial, legal, medical, or safety consequences.

11. Privacy

Offline features are designed to operate without requiring an internet connection.

When an online feature is used, information necessary to process that request may leave the device. The application should clearly identify when a request is being sent online.

12. Changes to These Terms

These Terms may be updated when the application or its services materially change. When appropriate, users will be shown the updated Terms and asked to accept the new version.

13. Contact

For questions, bug reports, privacy concerns, or other issues relating to Offline AI, use the contact information provided within the application.

14. Acceptance

By selecting "I Agree", you confirm that you have read and agree to these Terms and Conditions.
                """.trimIndent(),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.78f),
                lineHeight = 21.sp
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = onAccepted,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text("I Agree")
        }
    }
}
