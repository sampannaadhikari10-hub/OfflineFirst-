package com.offlineai.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.offlineai.ui.chat.ChatScreen
import com.offlineai.ui.models.ModelSelectionScreen
import com.offlineai.ui.onboarding.NameScreen
import com.offlineai.ui.onboarding.TermsScreen
import com.offlineai.ui.onboarding.WelcomeScreen

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "welcome"
    ) {
        composable("welcome") {
            WelcomeScreen(
                onContinue = { navController.navigate("terms") }
            )
        }
        composable("terms") {
            TermsScreen(
                onAccepted = { navController.navigate("name") }
            )
        }
        composable("name") {
            NameScreen(
                onContinue = {
                    navController.navigate("models") {
                        popUpTo("welcome") { inclusive = true }
                    }
                }
            )
        }
        composable("models") {
            ModelSelectionScreen(
                onModelReady = {
                    navController.navigate("chat") {
                        popUpTo("models") { inclusive = true }
                    }
                }
            )
        }
        composable("chat") {
            ChatScreen()
        }
    }
}
