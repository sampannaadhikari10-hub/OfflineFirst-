# Offline AI

Minimal & aesthetic offline AI chatbot for Android.

## Features
- Clean, minimal design
- 3 AI options (Fast / Balanced / Smart)
- Shows only: Parameters, Size, Best for
- Private & on-device after setup
- Simple navigation

## How to use
1. Open in Android Studio
2. Sync Gradle
3. Run on device

## Note
Currently uses temporary replies.  
Real model download + Llamatik integration can be added next.
